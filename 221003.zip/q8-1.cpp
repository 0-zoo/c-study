#include <iostream>
#include "q8.h"
using namespace std;

void BestComImpl::SimpleFunc(void){
  cout <<"BestCom이 정의한 함수" << endl;
}

void ProgComImpl::SimpleFunc(void){
  cout << "ProgCom이 정의한 함수" << endl;
}