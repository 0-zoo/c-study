#include <iostream>

using namespace std;

int main() {
	char name[50];
	char number[50];

	cout << "name: ";
	cin >> name;
	cout << "number: ";
	cin >> number;

	cout << name << " " << number;
}