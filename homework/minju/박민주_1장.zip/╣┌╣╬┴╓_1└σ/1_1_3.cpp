#include <iostream>

using namespace std;

int main() {
	int num;
	cout << "number: ";
	cin >> num;

	for (int i = 1; i <= 9; i++) {
		cout << num << "x" << i << "=" << i * num << endl;
	}

}